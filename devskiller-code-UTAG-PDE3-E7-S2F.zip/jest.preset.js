module.exports = {
    testTimeout: 15 * 1000,
    transformIgnorePatterns: [`node_modules/(?!.*.mjs$)`]
};
