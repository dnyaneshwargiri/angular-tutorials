import { ChangeDetectionStrategy, Component, forwardRef, Input } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';

@Component({
    selector: 'xc-product-list-settings',
    templateUrl: './product-list-settings.component.html',
    styleUrls: ['./product-list-settings.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    providers: [
        /* TODO: provide NG_VALUE_ACCESSOR. */
    ]
})
export class ProductListSettingsComponent implements ControlValueAccessor {

    @Input() minCount!: number;
    @Input() maxCount!: number;

    value!: number;
    initialValue!: number;
    touched = false;
    disabled = false;

    private onChangeFn?: (v: number) => void;
    private onTouchFn?: () => void;

    /* TODO: implement the logic for it to work like an input element. */

    writeValue(obj: any): void {
        throw new Error('Method not implemented.');
    }
    registerOnChange(fn: any): void {
        throw new Error('Method not implemented.');
    }
    registerOnTouched(fn: any): void {
        throw new Error('Method not implemented.');
    }
    setDisabledState?(isDisabled: boolean): void {
        throw new Error('Method not implemented.');
    }
}
