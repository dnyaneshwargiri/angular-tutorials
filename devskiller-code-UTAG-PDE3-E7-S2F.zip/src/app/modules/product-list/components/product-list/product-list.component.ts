import { ChangeDetectionStrategy, Component, Input } from '@angular/core';

@Component({
    selector: 'xc-product-list',
    templateUrl: './product-list.component.html',
    styleUrls: ['./product-list.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class ProductListComponent {
    /* TODO: Fetch list of products providing a limit count and update the list everytime this value changes. */

    @Input() count!: number;
}
