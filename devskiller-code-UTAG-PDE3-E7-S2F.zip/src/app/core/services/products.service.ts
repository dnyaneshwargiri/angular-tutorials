import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class ProductsService {

    constructor(private readonly httpClient: HttpClient) {
    }

    fetchProducts$(count: number): Observable<> {
        /* TODO: fetch the product list. */
    }

}
